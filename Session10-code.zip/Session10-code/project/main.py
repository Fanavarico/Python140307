from manager import *

class Main:
    manager1=InventoryManager()
    while True:
        i=input('enter add/remove/edit/display/search/details/exit')
        if i=='add':
            id_i,name,number,price=input('info').split(',')
            item1=manager1.create_item(id_i,name,int(number),int(price))
            manager1.add_item(item1)

        elif i=='remove':
            id_ir=input('enter id')
            manager1.remove_item(id_ir)
        elif i=='edit':
           id_ie= input('enter id ')
           manager1.edit_item(id_ie)
        elif i=='display':
            manager1.display_item()
        elif i=='search':
            ns=input('enter name')
            manager1.item_search(ns)
        elif i=='details':
            manager1.item_details()

        if i=='':
            continue
        if i=='exit':
            break
if __name__=='__main__':
    Main()
