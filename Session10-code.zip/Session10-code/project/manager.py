from item import *

class InventoryManager:
    def __init__(self):
        self.items={}
    def create_item(self,id_i,name,number,price):
        new_item=Item(id_i,name,number,price)
        return new_item
    def add_item(self,item):
        if item.id_i not in self.items:
            self.items[item.id_i]=item
            print('added')
        else:
            print('exists')
    def remove_item(self,id_i):
        if id_i in self.items:
            del self.items[id_i]
            print('removed')
        else:
            print('not exists')
    def display_item(self):
        for item in self.items.values():
            print(item)
    def edit_item(self,id_i):
        if id_i in self.items:
            new_name=input('enter new name : ')
            new_number=input('enter new number :')
            new_price=input('enter new price : ')
            self.items[id_i].name=new_name or self.items[id_i].name
            self.items[id_i].number=int(new_number or self.items[id_i].number)
            self.items[id_i].price=int(new_price or self.items[id_i].price)
        else:
            print('not found')
    def item_search(self,name):
        for item in self.items.values():
            if item.name ==name:
                print(item)

    def item_details(self):
        length=len(self.items)
        print(f'length of items is : {length} ')
        total_price=[]
        for item in self.items.values():
            total_price.append(item.price)
        sum_price=sum(total_price)
        print(f'sum of price {sum_price}')




if __name__=='__main__':
    m1=InventoryManager()
    #y=m1.create_item('5','M',4,688)
    #print('create_item',y)
    #print(type(y))
    #print(m1.items)item1
    #print(y.get_name())
    print(m1.items)
    item1=m1.create_item('4','n1',60,90)
    #m2=InventoryManager()
    item2=m1.create_item('5','n3',98,7)

    item3=m1.create_item('100','n3',6,8)
    m1.add_item(item3)
    print(item1)
    m1.add_item(item1)
    m1.add_item(item2)
    #m2.add_item(item2)
    print(m1.items.values())
    #m1.remove_item('100')
    #print(m1.items)
    #m1.display_item()
    #m1.edit_item('100')
    m1.item_search('n3')
    #m1.display_item()
