with open('C:/Users/EZ-Tech/Desktop/second.txt','w') as f:
    l1='hello t'
    l2='hello a'
   
    f.write(l1)
    f.write('\n')
    f.write(l2)    