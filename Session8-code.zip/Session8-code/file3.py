ad='C:/Users/EZ-Tech/Desktop/second.txt'
'''with open (ad,'r') as f1:
    t=f1.readline()
    s=f1.readline()
    d=f1.readline()
    print(d)


with open (ad,'r') as f1:
    for i in f1:
        print(i)'''
        
with open(ad,'r') as f2:
    data=f2.readlines(18)
    print(data)
    print(type(data))
    
        