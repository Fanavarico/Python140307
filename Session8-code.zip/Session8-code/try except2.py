try:
    int('ali')
except  ValueError as ve:
    print(ve)


print('hello')
