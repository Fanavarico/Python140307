balance=100
def deposit(amount):
    global balance
    balance+=amount
    return balance

def withdraw(amount):
    global balance
    if amount>balance:
        print('error')
    else:
        balance-=amount
    return balance

a=deposit(10)
print(a)
s=withdraw(70)
print(s)

