with open('example.txt', 'w+') as file:
    file.write('Hello, world!')
    file.seek(3)
    content = file.read()
    print(content)