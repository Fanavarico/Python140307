'''a=float(input('first :'))
b=float(input('second : '))

try :
    d=a/b
    print(d)
except ZeroDivisionError as ze:
    print(ze)

finally:
    print('bye')    
#print('hello')

a=float(input('first :'))
b=float(input('second : '))

try :
    d=a/b
    print(d)
except ZeroDivisionError as ze:
    print(ze,'enter new value :')
    i=float(input('new: '))
    d=a/i
    print(d)
    
    
def f(i,j):
    try :
        r=i/j
        print(r)
    except ZeroDivisionError as ze:
        print(ze)
        h=float(input('new'))
        y=i/h
        print(y)
        
        
a=float(input('first :'))
b=float(input('second : '))

f(a,b)'''



   
def f(i,j):
    try :
        r=i/j
        print(r)
    except ZeroDivisionError as ze:
        print(ze)
        j=float(input('new'))
        f(i,j)
        
        
a=float(input('first :'))
b=float(input('second : '))

f(a,b)