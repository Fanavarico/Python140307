i=int(input('enter '))
if i==9:
    raise 'error'
    
else:
    print(i)
print('hello')

