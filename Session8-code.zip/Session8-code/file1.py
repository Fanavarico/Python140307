f=open('C:/Users/EZ-Tech/Desktop/first.txt','w')
l1='hello world'
l2='hello python'
f.write(l1)
f.write('\n')
f.write(l2)
f.close()