ad1='C:/Users/EZ-Tech/Desktop/n1.txt'
ad2='C:/Users/EZ-Tech/Desktop/n2.txt'
'''with open(ad1,'r') as f1,open(ad2,'w') as f2:
    for i in f1:
        f2.write(i)'''
        
with open(ad1,'r+') as m:
    print(m.read())
    l1='ttttt'
    m.write(l1)
    