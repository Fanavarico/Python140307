l=['yes','yes','no','yes','no']
ad='C:/Users/EZ-Tech/Desktop/n1.txt'
'''
with open(ad,'w+') as f:
    for i in l:
        f.write(i)
        f.write('\n')
    f.seek(0)
    print(f.read())
    

d={'yes':0,'no':0}
k=[]

with open(ad,'w') as f:
    for i in l:
        f.write(i)
        f.write('\n')
        
        
with open(ad,'r') as f1:
    g=f1.readlines()
    #print(g)
    for i in g:
        i=i.strip()
        if i=='yes' :
            d['yes']+=1
 
        elif i=='no':
            d['no']+=1
            
            
print(d)'''

'''
d={}
with open(ad,'r') as f1:
    g=f1.readlines()
    #print(g)
    for i in g:
        i=i.strip()
        if i not in d:
            d[i]=1
        elif i in d:
            d[i]+=1
            
            
print(d)'''


d={}
with open(ad,'r') as f1:
    g=f1.readlines()
    #print(g)
    for i in g:
        i=i.strip()
        d[i]=d.get(i,0)+1
   
        
        
print(d)