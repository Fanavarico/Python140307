try: 
    5/7
    try:
        print(n)
        
    except NameError as ne:
        print(ne)
        
except ZeroDivisionError as ze:
    print(ze)
    
print('hello')
    
