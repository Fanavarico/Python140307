def f():
    
    try:
        i=int(input('enter :'))
        if i==9:
            raise ValueError ('not 9')
        print(i/8)
    except ValueError as ve:
        print(ve)
        

f()

print('hello')
