l1=[9,8]
l1[0]='ali'
print(l1)
'''
print(dir(l1))

b='ali'
print(isinstance(b,int))'''