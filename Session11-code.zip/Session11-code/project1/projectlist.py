class MyList(list):

    def __init__(self,data=[]):
        if self.all_str(data):
            super().__init__(data)
        else:
            raise ValueError ('only str')

    @staticmethod
    def all_str(data):
        for item in data:
            if not isinstance(item,str):
                return False
            else:
                return True
    def show_data(self):
        print(self)

    def append(self, value):
        if isinstance(value,str):
            super().append(value)
        else:
            raise ValueError ('only string')
    def insert(self,value,index):
        if isinstance(value,str):
            super().insert(index,value)
        else:
            raise ValueError('str only')
    def extend(self,new_list):
        if all(isinstance(item,str) for item in new_list):
            super().extend(new_list)
        else:
            raise ValueError ('only str')

    def __setitem__(self, index, value):
        if isinstance(value,str):
            super().__setitem__(index,value)
        else:
            raise ValueError ('only str')

l1=MyList(['5','ali'])
#print(l1)
#l1.show_data()
#print(dir(l1))
l1.append('reza')
#l1.insert('19',1)
#print(l1)
l1.extend(['12','hassan'])


#print(l1)
l1[2]='7777'
print(l1)