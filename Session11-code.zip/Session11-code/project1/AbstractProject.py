from abc import ABC,abstractmethod

'''class myclass(ABC):
    @abstractmethod
    def my_method(self):
        pass

mc=myclass()'''

class Product(ABC):
    def __init__(self,id_i, name,category,price):
        self.id_i=id_i
        self.name=name
        self.category=category
        self.price=price
    def __str__(self):
        return f'ID:{self.id_i},Name:{self.name},Category:{self.category},Price:{self.price}'

    @abstractmethod
    def discribe_product(self):
        pass


class Book(Product):
    def __init__(self,id_i, name,category,price,author,pages ):
        super().__init__(id_i,name,category,price)
        self.author=author
        self.pages=pages

    def __str__(self):
        return f'{super().__str__()},author :{self.author},pages: {self.pages}'

    def discribe_product(self):
        print(f'book by {self.pages}, author : {self.author}')



class Laptop(Product):
    def __init__(self, id_i, name, category, price, processor, ram):
        super().__init__(id_i,name,category,price)
        self.processor = processor
        self.ram = ram

    def __str__(self):
        return f' {super().__str__()}, Processor :{self.processor}, RAM:{self.ram}'

    def discribe_product(self):
        print(f'processor {self.processor} and ram : {self.ram}')


#p1=Product(2,'n1','c4',90)
b1=Book(8,'b11','c5',90,'a1',45)
print(b1)
b1.discribe_product()