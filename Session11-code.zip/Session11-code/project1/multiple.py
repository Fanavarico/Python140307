class Product:
    def __init__(self,id_i, name,category,price):
        self.id_i=id_i
        self.name=name
        self.category=category
        self.price=price
    def __str__(self):
        return f'ID:{self.id_i},Name:{self.name},Category:{self.category},Price:{self.price}'


class ElectronicProduct:
    def __init__(self,brand):
        self.brand=brand
    def __str__(self):
        return f'brand :{self.brand}'

class Laptop(Product,ElectronicProduct):
    def __init__(self, id_i, name, category,price,brand,processor,ram):
        Product.__init__(self,id_i, name, category, price)
        ElectronicProduct.__init__(self,brand)
        self.processor=processor
        self.ram=ram

    def __str__(self):
        return f'{Product.__str__(self)},{ElectronicProduct.__str__(self)},processor:{self.processor},' \
               f'ram : {self.ram}'


l1=Laptop('12','laptop1','c1',20000,'hp','i7',16)
print(l1)