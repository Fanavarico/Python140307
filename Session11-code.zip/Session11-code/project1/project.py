class Product:
    def __init__(self,id_i, name,category,price):
        self.id_i=id_i
        self.name=name
        self.category=category
        self.price=price
    def __str__(self):
        return f'ID:{self.id_i},Name:{self.name},Category:{self.category},Price:{self.price}'


class Book(Product):
    def __init__(self,id_i, name,category,price,author,pages ):
        super().__init__(id_i,name,category,price)
        self.author=author
        self.pages=pages

    def __str__(self):
        return f'{super().__str__()},author :{self.author},pages: {self.pages}'


class Laptop(Product):
    def __init__(self, id_i, name, category, price, processor, ram):
        super().__init__(id_i,name,category,price)
        self.processor = processor
        self.ram = ram

    def __str__(self):
        return f' {super().__str__()}, Processor :{self.processor}, RAM:{self.ram}'



b1=Book(1,'b1','tarikh',300,'a1',800)
print(b1)
l1=Laptop(4,'l1','c3',900,'c45',18)
print(l1)