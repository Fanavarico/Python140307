class Product:
    def __init__(self,id_i, name,category,price):
        self.id_i=id_i
        self.name=name
        self.category=category
        self.price=price
    def __str__(self):
        return f'ID:{self.id_i},Name:{self.name},Category:{self.category},Price:{self.price}'

class ElectronicProduct(Product):
    def __init__(self,id_i,name,category,price,brand):
        super().__init__(id_i,name,category,price)
        self.brand=brand
    def __str__(self):
        return f'{super().__str__()},brand :{self.brand}'

class Laptop(ElectronicProduct):
    def __init__(self,id_i,name,price,category,processor,ram,brand):
        super().__init__(id_i,name,category,price,brand)
        self.processor=processor
        self.ram=ram
    def __str__(self):
        #return ' processor: {0},ram: {1}'.format(self.processor,self.ram)
        return f'{super().__str__()},processor :{self.processor},ram:{self.ram}'


l1=Laptop(13,'l12',9000,'c3','i8',32,'b1')
print(l1)