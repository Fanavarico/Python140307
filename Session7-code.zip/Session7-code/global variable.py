'''def f():
    global x
    x=6
    print(x)
    
f()    
print(x)  '''

'''x=5
def f(x):
    
    
    print(x)
    x=8
    print(x)
    
f(x)  
print(x)  '''

'''x=5
def f():
    global x
    print(x)
    x=8
    print(x)
    
f()  
print(x)'''


x=5
def f():
    print(x)
    
f()  
print(x)



    
    
