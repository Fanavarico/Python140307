def f(*t):
    print(t)
    
f(5,5,2,3,55,2,9,1,4)   
 