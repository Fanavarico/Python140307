'''def f(a,*t):
    print(a,t)

f(3)'''

'''def f(a,b=7,*t):
    print(a,b,t)
    
f(1)   '''


'''def f(a,b=7,*t):
    print(a,t,b)
    
f(1,5,6,4,3)  '''  


def f(a,b=7,*t):
   # print(a+b+sum(t))
   #print(sum((a,b,t)))
   s=0
   for i in t:
       s+=i
       
   #print(a+b+s)  
   print(s)
   
    
f(1,5,6,4,3)    
 
 