def f(i,j):
    try : 
        r=i/j
        print(r)
    except ZeroDivisionError as ze:
        print(ze)
        j=float(input('new'))
        f(i,j)
       
        
a=num1 = float(input("Enter the first number: "))
b=num2 = float(input("Enter the second number: "))

f(a,b)        