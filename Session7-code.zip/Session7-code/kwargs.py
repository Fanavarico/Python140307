'''def f(**t):
    print(t)
    
f(a=7,b=6,c=4)  '''

def f(a,*y,**t):
    print(a,t,y)
    
f(9,6,b=6)    

    