def f(a):
    a['a']+=1
    a['b']-=1
    
d={'a':6,'b' : 15}  
f(d)  
f1=d['a']
f2=d['b']
print(f1)
print(f2)
