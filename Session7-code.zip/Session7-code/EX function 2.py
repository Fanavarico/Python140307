def count_upper_lower(text):
    # دیکشنری برای ذخیره تعداد حروف بزرگ و کوچک
    count_dict = {'u': 0, 'l': 0}

    # بررسی تک تک حروف رشته
    for char in text:
        if char.isupper():  # اگر حرف بزرگ باشد
            count_dict['u'] += 1
        elif char.islower():  # اگر حرف کوچک باشد
            count_dict['l'] += 1

    # چاپ نتیجه
    print("تعداد حروف بزرگ:", count_dict['u'])
    print("تعداد حروف کوچک:", count_dict['l'])

# گرفتن رشته از ورودی
input_text = input("یک رشته وارد کنید: ")
count_upper_lower(input_text)
