def count_words(sentence):
    d = {} 

    words = sentence.split()  

    for word in words: 
        if word in d: 
            d[word] += 1
        else:   
            d[word] = 1
    
    return d


input_sentence = input("enter sentence: ")
result = count_words(input_sentence)

print("تعداد کلمات در جمله:")
print(result)
