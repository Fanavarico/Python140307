'''def calculate_average(students):
    result = []  
    
    for student in students:
        avg = (student['m'] + student['f']) / 2   
        new_dict = {'id': student['id'], 'avg': avg}  
        result.append(new_dict)  
    
    return result


stu = [{'id': 6, 'm': 14, 'f': 18}, {'id': 99, 'm': 16, 'f': 20}]


output = calculate_average(stu)
print(output)
'''

stu = [{'id': 6, 'm': 14, 'f': 18}, {'id': 99, 'm': 16, 'f': 20}]
def stu_s(lst):
	for i in lst:
		n1=i.pop('f')
		n2=i.pop('m')
		i['avg']=(n1+n2)/2
	print(lst)

stu_s(stu)