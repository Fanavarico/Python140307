def f(t):
   return(t)
   
x=1,2,3,4
print(type(x))
a,b,c,d=f(x)
print(a)
print(b)