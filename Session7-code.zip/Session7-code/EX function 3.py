def count_characters(text):
    d = {}  
    
    for char in text:  
        if char in d: 
            d[char] += 1
        else: 
            d[char] = 1
    
    return d


input_text = input("enter: ")
result = count_characters(input_text)


print("تعداد کاراکترها در رشته:")
print(result)
