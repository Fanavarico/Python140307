def f(a,b):
    print(a,b)


f(4,6) 
f(3,b=7)   