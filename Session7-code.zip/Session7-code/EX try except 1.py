num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
def divide_numbers():
    

   try:
       

       
        result = num1 / num2
        print(f"Division result: {result}")
    
   except ZeroDivisionError as ze:
       
        print(ze)
    
   except ValueError: 
        print("Error: Please enter a valid number.")
   finally:
           print('bye') 

divide_numbers()
