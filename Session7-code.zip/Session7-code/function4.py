def f(a,b=9,c=8):
    print(a,b,c)
      
x=1
y=9
    
f()    