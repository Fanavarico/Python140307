def f(*t):
    s=0
    for i in t:
        s+=i
    print(s)

f(2,4,7,8,99,5,4)
