def f(a):
    a[0]+=1
    a[1]-=1
    
    
lst=[3,8]    
f(lst)

a1=lst[0]
a2=lst[1]
print(a1)
print(a2)
print(lst)
    