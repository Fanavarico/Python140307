def count_upper_lower(text):
  
    count_dict = {'u': 0, 'l': 0}

   
    for char in text:
        if char.isupper():
            count_dict['u'] += 1
        elif char.islower():
            count_dict['l'] += 1

   
    print("تعداد حروف بزرگ:", count_dict['u'])
    print("تعداد حروف کوچک:", count_dict['l'])


input_text = input("یک رشته وارد کنید: ")
count_upper_lower(input_text)
