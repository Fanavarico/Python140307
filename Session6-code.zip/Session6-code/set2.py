s={'apple','orange','mango','apple','cherry'}
f=s.pop()
print(f)
print(s)