l=['x','a','x','y','x','a','x']
d={}
for i in l:
    d[i]=d.get(i,0)+1

print(d)