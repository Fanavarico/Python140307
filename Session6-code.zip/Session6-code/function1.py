'''def hello():
    print('hello world')

hello()


def hello(s):
    print('hello ',s)
    
i=input('enter name : ')

hello(i)

def hello():
    return 'hello world'


o=hello()
print(o)
'''

def hello(j):
    return 'hello '+j

i=input('enter: ')
r=hello(i)
print(r)

