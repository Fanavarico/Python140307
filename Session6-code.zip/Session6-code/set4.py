l=[2,3,4,2,4,2]
l=set(l)
print(list(l))
print(l)

