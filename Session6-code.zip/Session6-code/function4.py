p=3.14
def mo(r):
    return p*r*2

def ma(r):
    return p*r*r

d=input('select محیط or مساحت :')

def main(s):
    a=int(input('enter raduis :'))
    if s=='محیط':
        print(f' mohit : {mo(a)}')
    elif s=='مساحت':
        print(f' masahat : {ma(a)}')
        
        
main(d)
        
        
        
        