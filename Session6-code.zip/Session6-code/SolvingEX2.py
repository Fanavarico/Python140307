l=[]
for i in range(10):
    n=int(input('enter : '))
    l.append(n)

print(l)

new_n=int(input('enter new number : '))
c=l.count(new_n)
#print(c)
if new_n in l:
    for i in range(c):
        l.remove(new_n)
    
else:
    for i in range(2):
        l.insert(0, new_n)
print(l)
