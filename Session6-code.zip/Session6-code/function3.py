def m(a,b):
    if a>b:
        return a
    else:
        return b
    
    
    
n1=int(input('first :'))
n2=int(input('second :'))
n3=int(input('third : '))

def g(x,y,z):
    return m(x,m(y,z))

print(g(n1,n2,n3))