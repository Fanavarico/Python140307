s={'apple','orange','mango','apple','cherry'}
#print(s)
#print(len(s))
#for i in s:
#    print(i)

#print('mango' in s)
#d=set()
#print(type(d))
#s.add('b')
#s.update(['c'])
#s.remove('apple' or 'mango')
#s.discard('apple' or 'mango')
#print(s)
#t=set()
#for _ in range():
a=input('enter :')
b=input('enter b')
s.update(a,b)
print(s)
    
