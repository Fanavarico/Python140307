def f(a,b):
    a+=1
    b-=1
    return a,b

#print(type(f(3,8)))
d,g=f(3,8)
print('d',d)
print('g',g)