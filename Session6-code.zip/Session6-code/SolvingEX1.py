d={'a':4,'b':2,'c':1}
s=0
'''for i in d.values():
   s=i+s 
   
print(s)'''

for i in d.keys():
    s=d[i]+s
    
print(s)