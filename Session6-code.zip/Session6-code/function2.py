def ad(a,b):
    return a+b

n1=input('first :')
n2=input('second :')
print(ad(n1,n2))