#private
'''class Product:
    def __init__(self, name, price):
        self.name = name
        self.__price = price #Private Attribute

    def __show_price(self):#Private Method
        return f'Price: {self.__price}'''''

'''
if __name__ == '__main__':
    p1 = Product('pro1', 800)

    #print(vars(p1))
    #p1._Product__price = 9000000
    #print(p1._Product__price)
    print(p1._Product__show_price())'''


#Protected
class Product:
    def __init__(self, name, price):
        self.name = name
        self._price = price #Protected Attribute

    def _show_price(self):#Protected Method
        return f'Price: {self._price}'



if __name__=='__main__':
    p1=Product('PRO1',9000000)
    #p1._price=10
    #print(p1._price)
    #print(vars(p1))
    print(p1._show_price())