class Product:
    def __init__(self,name,price ,category):
        self.name=name
        self.price=price
        self.category=category
    def __str__(self):
        return f'Name:{self.name},Price:{self.price},Category:{self.category} '

    def apply_discount(self):
        discount=self.price*0.1
        #self.price=self.price-discount
        self.price-=discount

    def show_price(self):
        return f'Price: {self.price}'



class Book(Product):
    def __init__(self,name,price,category):
        super().__init__(name,price,category)


    #def show_price(self):
     #   return f'Price: {self.price}'

    def apply_discount(self):
        discount=self.price*0.15
        self.price-=discount

class Laptop(Product):
    def __init__(self,name,price,category):
        super().__init__(name,price,category)

    #def show_price(self):
     #   return f'Price: {self.price}'

    def apply_discount(self):
        discount=self.price*0.05
        self.price-=discount



if __name__=='__main__':
    p1=Product('pro1',2000,'cp')
    b1=Book('bo1',5000,'cb')
    l1=Laptop('la1',10000,'cl')
    '''print(p1.show_price())
    print(p1)
    p1.apply_discount()
    print(p1.show_price())
    print(b1.show_price())
    b1.apply_discount()
    print(b1.show_price())'''
    print(l1.show_price())
    l1.apply_discount()
    print(l1.show_price())

