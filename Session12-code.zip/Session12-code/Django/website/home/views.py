from django.shortcuts import render
from django.shortcuts import HttpResponse
# Create your views here.

def x(request):
    return HttpResponse('به وب سایت من خوش آمدید')
