import mysql.connector
'''mydb=mysql.connector.connect(
    host='localhost',
    user='root',
    password='PassPass'
)
mycursor=mydb.cursor()
sql1="create database shop"
mycursor.execute(sql1)
sql2='show databases'
mycursor.execute(sql2)
i=mycursor.fetchall()
print(i)
'''
mydb=mysql.connector.connect(
    host='localhost',
    user='root',
    password='PassPass',
    database='onlineshop'
)
sql1='show tables'
mycursor=mydb.cursor()
mycursor.execute(sql1)
i=mycursor.fetchall()
print(i)
sql = "INSERT INTO UsersDetails (user_id,firstname, last_name, age) VALUES (3000,'aaa', 'bbb', 12)"
mycursor.execute(sql)
mydb.commit()
sql1="select * from usersdetails"
mycursor.execute(sql1)
o=mycursor.fetchall()
print(o)