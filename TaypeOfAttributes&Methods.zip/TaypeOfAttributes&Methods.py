class Student:
    num_of_student=0
    def __init__(self,name,stu_num,score):
        #instance attribute
        self.name=name
        self.is_valid(stu_num)
        self.stu_num=stu_num
        self.score=score
        #class attribute
        Student.num_of_student+=1
        
    def calc_avg(self):
        result=sum(self.score)/len(self.score)
        self.avg=result
    
    @classmethod
    def show_number(cls):
        print(cls.num_of_student)
    
    
    def __str__(self):
        return f'name:{self.name},student_number :{self.stu_num},score{self.score}'
        
    @staticmethod
    def is_valid(stu_num):
         if len(stu_num)!=4 or not stu_num.startswith('s'):
             raise ValueError('invalid student number')
    
        

s1=Student('n1','s123',[15,13,16])
s2=Student('n2','s323',[18,13,16])
try:
    s3=Student('n3','sf323',[18,13,16])
except Exception as e:
    print(e)
s4=Student('n4','s323',[18,13,16])
#s1.calc_avg()
#print(s1.avg)
Student.show_number()
#s1.show_number()
