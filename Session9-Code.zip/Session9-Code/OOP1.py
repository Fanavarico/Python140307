class Test:
    def set_var(self,a,b):
        self.a=a
        self.b=b
        
    def jam(self):
        return self.a+self.b
    
    def zarb(self):
        return self.a*self.b
    
ob1=Test()
x=int(input('first :'))
y=int(input('second:'))
ob1.set_var(x, y)
print(ob1.a)
print(ob1.b)
i=ob1.jam()
print(ob1.zarb())
print(i)    