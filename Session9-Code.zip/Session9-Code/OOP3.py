class Book:
    def __init__(self,author, name):
        self.author=author
        self.name=name
    
    def info(self):
        return f'author of {self.name} is {self.author}'
    

#a=input('name of author : ')
#n=input('name of book :')
book1=Book('a', 'b')
book2=Book('x','y')
print(book1.info())
print(book2.info())