
a='ali'
print(type(a))