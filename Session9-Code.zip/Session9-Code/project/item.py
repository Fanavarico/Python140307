class Item:
    def __init__(self, id_i,name,number,price):
        self.id_i=id_i
        self.name=name
        self.number=number
        self.price=price

    def __str__(self):
        return f'ID:{self.id_i} , Name:{self.name} , Number:{self.number} , Price:{self.price}'
    def get_price(self):
        return f'Price: {self.price}'
    def get_name(self):
        return f'name:{self.name}'

if __name__=='__main__':
    i=Item('1','A',5,900)
    print(i)