from item import *

class InventoryManager:
    def __init__(self):
        self.items={}
    def create_item(self,id_i,name,number,price):
        new_item=Item(id_i,name,number,price)
        return new_item
m1=InventoryManager()
y=m1.create_item('5','M',4,688)
print('create_item',y)
print(type(y))
print(m1.items)