class Student:
    def __init__(self,name,age,stu_num,score):
        self.name=name
        self.age=age
        self.stu_num=stu_num
        self.score=score
    def __str__(self):
        return f'name of{self.stu_num} is {self.name} and\
            age of student is {self.age} and score is\
                {self.score}'
    
    
    
s1=Student('A', 10, 9, 13)
print(s1)
print(type(s1))