class Test:
    def __init__(self,x,y):
        self.a=x
        self.b=y
        
    def jam(self):
        return self.a+self.b
    def zarb(self):
        return self.a*self.b
    
ob=Test(4,8)
print(ob.jam())
print(ob.zarb())