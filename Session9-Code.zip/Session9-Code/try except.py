try :
    i=int(input('enter :'))
    x=i/0
    print(x)
except(ValueError,ZeroDivisionError) as e:
    print(e)

print('hello')