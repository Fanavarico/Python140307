class Account:
    def __init__(self, owner, balance):
        self.owner=owner
        self.balance=balance
        
    def deposite(self,amount):
        self.balance+=amount

    def withdraw(self,amount):
        if amount>self.balance:
            print('balance less')
        else:
            self.balance-=amount

a=Account('A', 100)

a.deposite(433)

print(a.balance)
a.withdraw(800)
print(a.balance)

